sendRequest = (data)=>{

fetch('/account/account.php', {
  method: 'POST',
  body: data,
}).then(data => {
  console.log('Success:', data);
}).catch((error) => {
  console.log(error);
});
}


let login = document.querySelector('.login');
let sign = document.querySelector('.sign');

login.addEventListener('click',()=>{
    
})
sign.addEventListener('click',()=>{
    let password = document.querySelector('.sign_pass').value.replace(/\s/g,'');
    let email = document.querySelector('.sign_email').value.replace(/\s/g,'');
    let username = document.querySelector('.sign_user').value.replace(/\s/g,'');
     if(username === '' || username == null){ 
  M.toast({html: 'Username is required!'})
 }else if(email === '' || email == null){ 
  M.toast({html: 'Email is required!'})
 }else if(password.length <= 6){ 
     M.toast({html: 'Password must be longer then 6 characters'})
 }else if(password.length >= 15){ 
     M.toast({html: 'Password must be less then 15 characters'})
 }else{
     let data = {
         'type':'sign',
         'username':username,
         'password':password,
         'email':email
     }
     const updateRequest = new FormData();
updateRequest.append('type', 'sign');
updateRequest.append('username', username);
updateRequest.append('email', email);
updateRequest.append('password', password);
     sendRequest(updateRequest)
 }
})