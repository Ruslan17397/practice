<?php
require "/db/connect.php"
$json = json_decode($_POST['body']);
if($json.type == 'sign'){
$user = R::dispense('users');
$user->username = $json.username;
$user->email = $json.password;
$user->password = $json.email;
R::store($user);
}
?>