
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo">Logo</a>
      <ul  class="right hide-on-med-and-down">
        <li><a class="modal-trigger" href="#modal1">Log in/Sign up</a></li>
      </ul>
    </div>
  </nav> 
  
 <div id="modal1" class="modal">
    <div class="modal-content">
       <div class="row">
    <div class="col s12">
      <ul class="tabs">
        <li class="tab col s6"><a class="active" href="#test1">Log in</a></li>
        <li class="tab col s6"><a  href="#test2">Sign up</a></li>
      </ul>
    </div>
    <div id="test1" class="col s12">
                <div class="row">
    <div class="col s12">
      <div class="row">
        <div class="input-field col s12">
          <input id="icon_prefix" type="text" class="validate em_login">
          <label for="icon_prefix">Email</label>
        </div>
         <div class="input-field col s12">
          <input id="password" type="password" class="validate pass_login">
          <label for="password">Password</label>
        </div>
      </div>
      <center>
      <button class="waves-effect waves-light btn login">Log in</button></center>
    </div>
  </div>
        
    
        
    </div>
    <div id="test2" class="col s12">
 <div class="row">
    <div class="col s12">
      <div class="row">
       <div class="input-field col s12">
          <input id="icon_prefix" type="text" class="validate sign_user">
          <label for="icon_prefix">Username</label>
        </div>
        <div class="input-field col s12">
          <input id="icon_prefix" type="text" class="validate sign_email">
          <label for="icon_prefix">Email</label>
        </div>
         <div class="input-field col s12">
          <input id="password" type="password" class="validate sign_pass">
          <label for="password">Password</label>
        </div>
      </div>
      <center>
      <button class="waves-effect waves-light btn sign">Sign up</button></center>
    </div>
  </div>
        
        
    </div>
  </div>
    </div>
  </div>
  
  <div class="contain">
      <div class="row">
          <div class="col s4">
              <div class="card blue-grey darken-1">
        <div class="card-content white-text">
          <span class="card-title">Card Title</span>
          <p>I am a very simple card. I am good at containing small bits of information.
          I am convenient because I require little markup to use effectively.</p>
        </div>
      </div>              
          </div>
      </div>
  </div>
  
  
  <a class="btn-floating btn-large waves-effect waves-light red add-art"><i class="material-icons">add</i></a>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
     <script>
      document.addEventListener('DOMContentLoaded', function() {
    let elems = document.querySelectorAll('.modal');
    let instances = M.Modal.init(elems);
  });
let tabs = document.querySelector('.tabs');
         var instance = M.Tabs.init(tabs);

    </script>
    <script src="js.js"></script>
</body>
</html>